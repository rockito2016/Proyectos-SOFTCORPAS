<?php
session_start();
require_once ("../conexion.php");
require_once ("../Model/Repositorio_model.php");

header('Content-Type: application/json');

$ruta_archivos = "../../Prestador";

try {
    $insertar_repositorio = new Repositorio_model($miconexion, $ruta_archivos);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $accion = $_POST["accion"] ?? '';

        if ($accion === 'crearRepositorio') {
            if (isset($_FILES["archivo"]) && isset($_POST["periodo"]) && isset($_POST["tipificacion"]) && isset($_POST["descripcion"])) {
                $archivos = $_FILES["archivo"]["name"];
                $periodo = $_POST["periodo"];
                $tipificacion = $_POST["tipificacion"];
                $descripcion = $_POST["descripcion"];
                $archivos_temporales = $_FILES["archivo"]["tmp_name"];
                $archivos_tamanos = $_FILES["archivo"]["size"];
                $archivos_tipos = $_FILES["archivo"]["type"];
                $idPrestador = $_SESSION['prestador']['idPrestador'] ?? null;

                if (!$idPrestador) {
                    echo json_encode(["error" => "La sesión no contiene un ID de prestador"]);
                    exit;
                }

                if ($insertar_repositorio->periodoExiste($periodo, $idPrestador)) {
                    echo json_encode(["error" => "El periodo ya está registrado para este prestador"]);
                    exit;
                }

                $idTipificacion = null;
                if (!$insertar_repositorio->existe_Archivo($archivos[0], $idPrestador)) {
                    // Solo insertamos la tipificación si el archivo no existe
                    if (!$insertar_repositorio->Existe_tipificacion($tipificacion, $idPrestador)) {
                        $idTipificacion = $insertar_repositorio->insertar_Tipificacion($idPrestador, $tipificacion, $descripcion);
                    } else {
                        $idTipificacion = $insertar_repositorio->obtener_Id_Tipificado($tipificacion, $idPrestador);
                    }
                }

                $errores = [];
                foreach ($archivos as $i => $archivo_nombre) {
                    $archivo_nombre = str_replace(' ', '_', $archivo_nombre);
                    $archivo_nombre = preg_replace('/^a-zA-ZO-9_\.]/', '_', $archivo_nombre);
                    $ruta_completa = "{$ruta_archivos}/{$idPrestador}/{$periodo}/{$archivo_nombre}";

                    if ($archivos_tamanos[$i] > 1 * 1024 * 1024 * 1024) {
                        $errores[] = "El archivo {$archivo_nombre} excede el tamaño máximo de 1GB.";
                    }

                    if ($archivos_tipos[$i] !== 'application/pdf') {
                        $errores[] = "El archivo {$archivo_nombre} no es un archivo PDF.";
                    }

                    if ($insertar_repositorio->existe_Archivo($ruta_completa, $idPrestador)) {
                        $errores[] = "El archivo ya existe en la base de datos: {$archivo_nombre}";
                    }
                }

                if (!empty($errores)) {
                    echo json_encode(["error" => implode("<br>", $errores)]);
                    exit;
                }

                // Crear carpetas necesarias
                $ruta_prestador = "{$ruta_archivos}/{$idPrestador}";
                $ruta_periodo = "{$ruta_prestador}/{$periodo}";
                $insertar_repositorio->crear_Carpeta($ruta_prestador);
                $insertar_repositorio->crear_Carpeta($ruta_periodo);

                foreach ($archivos as $i => $archivo_nombre) {
                    $archivo_nombre = str_replace(' ', '_', $archivo_nombre);
                    $archivo_temporal = $archivos_temporales[$i];
                    $fileSizeKB = round($archivos_tamanos[$i] / 1024);
                    $ruta_completa = "{$ruta_periodo}/{$archivo_nombre}";

                    $resultado = $insertar_repositorio->insertar_Archivo($ruta_completa, $periodo, $fileSizeKB, $idPrestador, $archivo_temporal, $idTipificacion);

                    if (isset($resultado['error'])) {
                        $errores[] = $resultado['error'];
                    }
                }

                if (!empty($errores)) {
                    echo json_encode(["error" => implode("<br>", $errores)]);
                } else {
                    echo json_encode(["resultados" => "Todos los archivos se han cargado correctamente."]);
                }
            } else {
                echo json_encode(["error" => "No se recibieron datos correctamente."]);
            }
        } else {
            echo json_encode(["error" => "Acción no válida."]);
        }
    } else {
        echo json_encode(["error" => "No se recibieron datos correctamente."]);
    }
} catch (PDOException $e) {
    echo json_encode(["error" => "Error de conexión a la base de datos: "]);
}
