<?php

$host = "localhost";
$usuario = "root";
$password = " ";
$dbname = "soporte_facturas";

try {
    $miconexion = new PDO('mysql:host=localhost;dbname=soporte_facturas', 'root', '');
    $miconexion->exec("SET NAMES 'UTF8';");
    $miconexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
