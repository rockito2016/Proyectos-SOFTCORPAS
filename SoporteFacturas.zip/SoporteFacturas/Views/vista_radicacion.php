<?php
session_start();

// Función para cerrar sesión
function logout()
{
    session_unset(); // Limpiar todas las variables de sesión
    session_destroy(); // Destruir la sesión
    header("Location: ../Login/login.php"); // Redirigir al formulario de inicio de sesión
    exit();
}

// Verificar si no se ha iniciado sesión
if (!isset($_SESSION['prestador'])) {
    // Redirigir al formulario de inicio de sesión
    echo "<script>
            alert('Debes iniciar sesión para acceder a esta página.');
            window.location.href = '../Login/login.php'; // Redirigir al formulario de inicio de sesión
          </script>";
    exit();
}

// Verificar si se ha hecho clic en el botón de logout
if (isset($_POST['logout'])) {
    logout();
}

// Verificar si se ha enviado el formulario de carga de archivo
if (isset($_POST['accion']) && $_POST['accion'] === 'crearRepositorio') {
}

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cargar Archivo</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-fileinput/5.1.3/css/fileinput.min.css">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <link rel="stylesheet" href="../style/style.css">
</head>

<body>
    <header>
        <nav class="bg-white shadow-lg">
            <div class="container mx-auto px-6 py-3">
                <div class="flex items-center justify-between">
                    <div class="flex items-center">
                        <button class="text-gray-500 focus:outline-none lg:hidden" id="navbar-toggle">
                            <i class="fa fa-bars"></i>
                        </button>
                    </div>
                    <div class="flex items-center justify-center space-x-4">
                        <a class="text-gray-700 hover:text-blue-500" href="vista_externo.php">
                            <i class="fa-solid fa-home mr-2"></i>Inicio
                        </a>
                        <form method="POST" action="" class="inline">
                            <button type="submit" name="logout"
                                class="text-gray-700 hover:text-blue-500 focus:outline-none">
                                <i class="fa-solid fa-right-from-bracket mr-2"></i>Logout
                            </button>
                        </form>
                        <span class="text-green-500 flex items-center">
                            <i class="fa-solid fa-circle-dot fa-bounce mr-2"></i>Activo
                        </span>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <div class="bg-white p-6 rounded-lg shadow-lg">
        <div class="flex items-center mb-4">
            <i class="fas fa-user-shield text-blue-500 text-3xl mr-4"></i>
            <div>
                <p class="text-2xl font-semibold">Bienvenido, <?php echo $_SESSION['prestador']['prestador']; ?></p>
                <p class="text-gray-600">Código del Prestador: <?php echo $_SESSION['prestador']['codPrestador']; ?></p>
            </div>
        </div>
        <div class="container mx-auto mt-8 p-4 bg-white shadow-lg">
            <div class="flex items-center mb-4">
                <i class="fas fa-history text-2xl mr-2"></i>
                <div>
                    <h2 class="text-2xl font-bold">Historial de Búsqueda</h2>
                </div>
            </div>
            <main>
                <div class="flex mb-4">
                    <div class="relative mr-4 flex-1">
                        <input id="searchInput"
                            class="form-input block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:shadow-outline-blue focus:border-blue-300 sm:text-sm sm:leading-5"
                            type="text" placeholder="Buscar en el historial...">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-search text-gray-400"></i>
                        </div>
                    </div>
                    <div class="relative mr-4">
                        <select id="tipificacionInput"
                            class="form-select block w-full pl-3 pr-10 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:shadow-outline-blue focus:border-blue-300 sm:text-sm sm:leading-5">
                            <option value="">Tipificación</option>
                            <option value="HEV">HEV</option>
                            <option value="EPI">EPI</option>
                            <option value="PDX">PDX</option>
                            <option value="DQX">DQX</option>
                            <option value="RAN">RAN</option>
                            <option value="CRC">CRC</option>
                            <option value="TAP">TAP</option>
                            <option value="TNA">TNA</option>
                            <option value="FAT">FAT</option>
                            <option value="FMO">FMO</option>
                            <option value="OPF">OPF</option>
                            <option value="HAU">HAU</option>
                            <option value="HAO">HAO</option>
                            <option value="HAM">HAM</option>
                            <option value="PDE">PDE</option>
                        </select>
                    </div>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white">
                        <thead class="bg-gray-200">
                            <tr>
                                <th class="px-4 py-2">Fecha Subida</th>
                                <th class="px-4 py-2">Estado</th>
                                <th class="px-4 py-2">Archivo</th>
                                <th class="px-4 py-2">Periodo</th>
                                <th class="px-4 py-2">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="searchHistoryTable">
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>
    <script>
        $(document).ready(function () {
            function fetchHistorial(tipificacion = '') {
                var idPrestador = <?php echo $_SESSION['prestador']['idPrestador']; ?>;
                $.ajax({
                    url: '../Model/fetch_data.php',
                    method: 'GET',
                    data: { tipificacion: tipificacion, idPrestador: idPrestador },
                    success: function (response) {
                        console.log(response);
                        try {
                            var responseData = JSON.parse(response);
                            var tbody = $('#searchHistoryTable');
                            tbody.empty();
                            responseData.forEach(function (row) {
                                var fileName = row.archivo.split('/').pop().replace('.pdf', '');
                                var tr = $('<tr class="bg-white border-b transition duration-300 ease-in-out hover:bg-gray-100">');
                                tr.append('<td class="px-4 py-2">' + row.fecha_ingreso + '</td>');
                                tr.append('<td class="px-4 py-2">' + row.estado + '</td>');
                                tr.append('<td class="px-4 py-2">' + fileName + '</td>');
                                tr.append('<td class="px-4 py-2">' + row.periodo + '</td>');
                                tr.append('<td class="px-4 py-2"><button class="text-blue-500 hover:text-blue-700" onclick="viewFile(\'' + row.archivo + '\')"><i class="fas fa-eye mr-2"></i>Ver</button></td>');
                                tbody.append(tr);
                            });
                        } catch (error) {
                            console.error('Error al analizar la respuesta JSON:', error);
                            alert('Error al procesar la respuesta del servidor.');
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error('AJAX Error:', status, error);
                        console.error('Response:', xhr.responseText);
                        alert('Error fetching data.');
                    }
                });
            }

            function viewFile(filePath) {
                // Abrir el archivo en una nueva ventana o pestaña
                window.open(filePath, '_blank');
            }

            // Fetch data
            fetchHistorial();

            $('#tipificacionInput').change(function () {
                var tipificacion = $(this).val();
                fetchHistorial(tipificacion);
            });

            $('#searchInput').on('input', function () {
                var searchValue = $(this).val().toLowerCase();
                $('#searchHistoryTable tr').filter(function () {
                    $(this).toggle($(this).text().toLowerCase().indexOf(searchValue) > -1);
                });
            });
        });
    </script>
</body>

</html>