<?php
session_start();

// Función para cerrar sesión
function logout()
{
    session_unset(); // Limpiar todas las variables de sesión
    session_destroy(); // Destruir la sesión
    header("Location: ../Login/login.php"); // Redirigir al formulario de inicio de sesión
    exit();
}

// Verificar si no se ha iniciado sesión
if (!isset($_SESSION['prestador'])) {
    // Redirigir al formulario de inicio de sesión
    echo "<script>
            alert('Debes iniciar sesión para acceder a esta página.');
            window.location.href = '../Login/login.php'; // Redirigir al formulario de inicio de sesión
          </script>";
    exit();
}

// Verificar si se ha hecho clic en el botón de logout
if (isset($_POST['logout'])) {
    logout();
}

// Verificar si se ha enviado el formulario de carga de archivo
if (isset($_POST['accion']) && $_POST['accion'] === 'crearRepositorio') {
}

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cargar Archivo</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-fileinput/5.1.3/css/fileinput.min.css">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../style/style.css">
</head>

<body>
    <header>
        <nav class="bg-white shadow-lg">
            <div class="container mx-auto px-6 py-3">
                <div class="flex items-center justify-between">
                    <div class="flex items-center">
                        <button class="text-gray-500 focus:outline-none lg:hidden" id="navbar-toggle">
                            <i class="fa fa-bars"></i>
                        </button>
                    </div>
                    <div class="flex items-center justify-center space-x-4">
                        <a class="text-gray-700 hover:text-blue-500" href="vista_radicacion.php">
                            <i class="fa-solid fa-history mr-2"></i>Historial
                        </a>
                        <form method="POST" action="" class="inline">
                            <button type="submit" name="logout"
                                class="text-gray-700 hover:text-blue-500 focus:outline-none">
                                <i class="fa-solid fa-right-from-bracket mr-2"></i>Logout
                            </button>
                        </form>
                        <span class="text-green-500 flex items-center">
                            <i class="fa-solid fa-circle-dot fa-bounce mr-2"></i>Activo
                        </span>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <div class="bg-white p-6 rounded-lg shadow-lg">
        <div class="flex items-center mb-4">
            <i class="fas fa-user-shield text-blue-500 text-3xl mr-4"></i>
            <div>
                <p class="text-2xl font-semibold">Bienvenido, <?php echo $_SESSION['prestador']['prestador']; ?></p>
                <p class="text-gray-600">Código del Prestador: <?php echo $_SESSION['prestador']['codPrestador']; ?></p>
            </div>
        </div>
        <div class="mt-6">
            <h2 class="text-xl font-semibold mb-4">SOPORTE DE FACTURAS</h2>
            <form name="creaRepositorio" id="formulario-carga" method="POST" enctype="multipart/form-data"
                class="space-y-4">
                <input type="hidden" name="accion" value="crearRepositorio">

                <div class="form-group">
                    <label for="tipificacion" class="block text-gray-700">Tipificación:</label>
                    <div class="relative">
                        <select
                            class="block appearance-none w-full bg-white border border-gray-300 rounded-lg py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:border-blue-500"
                            id="tipificacion" name="tipificacion" required>
                            <option value="" disabled selected>Seleccione la tipificación</option>
                            <option value="HEV">HEV - Resumen de atención u hoja de evolución</option>
                            <option value="EPI">EPI - Epicrisis</option>
                            <option value="PDX">PDX - Resultado de los procedimientos de apoyo diagnóstico</option>
                            <option value="DQX">DQX - Descripción quirúrgica</option>
                            <option value="RAN">RAN - Registro de anestesia</option>
                            <option value="CRC">CRC - Comprobante de recibido del usuario</option>
                            <option value="TAP">TAP - Traslado asistencial de pacientes</option>
                            <option value="TNA">TNA - Transporte no
                                asistencial
                                ambulatorio de
                                la persona </option>
                            <option value="FAT">FAT - Factura de
                                venta por el
                                cobro a la
                                aseguradora
                                SOAT, la
                                ADRES o la
                                entidad que
                                haga sus veces </option>
                            <option value="FMO">FMO - Factura de
                                venta del
                                material de
                                osteosíntesis
                                expedida por el
                                proveedor </option>
                            <option value="OPF">OPF - Orden o prescripción facultativa</option>
                            <option value="HAU">HAU - Hoja de atención de urgencia</option>
                            <option value="HAO">HAO - Hoja de atención odontológica</option>
                            <option value="HAM">HAM - Hoja de administración de medicamentos</option>
                            <option value="PDE">PDE - Evidencia del envío del trámite respectivo</option>
                        </select>
                        <div
                            class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                            <i class="fas fa-caret-down"></i>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="descripcion" class="block text-gray-700">Descripción:</label>
                    <textarea class="w-full px-3 py-2 text-gray-700 border rounded-lg focus:outline-none"
                        id="descripcion" name="descripcion" rows="3" required></textarea>
                </div>

                <div class="form-group">
                    <label for="archivo" class="block text-gray-700">Seleccione archivos:</label>
                    <div id="file-drop-area" class="flex items-center justify-center w-full">
                        <div
                            class="border-dashed border-4 border-gray-300 rounded-lg p-4 w-full text-center bg-gray-100 relative">
                            <input type="file" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                id="archivo" name="archivo[]" accept=".pdf" multiple required>
                            <p class="mb-2 text-gray-600">Arrastra y suelta tus archivos aquí, o haz clic para
                                seleccionarlos</p>
                            <button type="button"
                                class="bg-blue-500 text-white px-3 py-2 rounded-lg hover:bg-blue-700 focus:outline-none">Seleccionar
                                archivos</button>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="periodo" class="block text-gray-700">Seleccione un periodo (MM/YYYY):</label>
                    <input type="text" class="w-full px-3 py-2 text-gray-700 border rounded-lg focus:outline-none"
                        id="periodo" name="periodo" placeholder="MM/YYYY" required>
                </div>
                <div class="form-group">
                    <label for="tamaño" class="block text-gray-700">Tamaño del archivo:</label>
                    <input type="text" class="w-full px-3 py-2 text-gray-700 border rounded-lg focus:outline-none"
                        id="tamaño" name="tamaño" readonly>
                </div>
                <div id="progress-container" class="w-full bg-gray-200 rounded-full h-4 overflow-hidden">
                    <div id="progress-bar" class="bg-blue-500 h-full text-center text-white text-xs leading-none"
                        style="width: 0%;">0%</div>
                </div>
                <button type="submit"
                    class="w-full bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-700 focus:outline-none">Cargar</button>
            </form>
        </div>
    </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-fileinput/5.1.3/js/fileinput.min.js"></script>
    <script
        src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="../JavaScript/script_repositorio.js"></script>
    <script>
        // Script para animación de ícono activo
        function animateIcon() {
            const icon = document.getElementById('activo-icon');
            icon.classList.add('fa-bounce');
            setTimeout(() => {
                icon.classList.remove('fa-bounce');
            }, 2000);
        }

        // Llamar la animación del ícono activo cada 5 segundos
        setInterval(animateIcon, 5000);
    </script>
    <script>
        // Manejo de arrastrar y soltar archivos
        const fileDropArea = document.getElementById('file-drop-area');
        const fileInput = document.getElementById('archivo');
        const fileSelectButton = fileDropArea.querySelector('button');

        fileDropArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.stopPropagation();
            fileDropArea.classList.add('border-blue-500');
        });

        fileDropArea.addEventListener('dragleave', (e) => {
            e.preventDefault();
            e.stopPropagation();
            fileDropArea.classList.remove('border-blue-500');
        });

        fileDropArea.addEventListener('drop', (e) => {
            e.preventDefault();
            e.stopPropagation();
            fileDropArea.classList.remove('border-blue-500');
            fileInput.files = e.dataTransfer.files;
        });

        fileSelectButton.addEventListener('click', () => {
            fileInput.click();
        });

        fileInput.addEventListener('change', () => {
            if (fileInput.files.length > 0) {
                fileDropArea.querySelector('p').textContent = `${fileInput.files.length} archivo(s) seleccionado(s)`;
            } else {
                fileDropArea.querySelector('p').textContent = 'Arrastra y suelta tus archivos aquí, o haz clic para seleccionarlos';
            }
        });
    </script>
</body>

</html>