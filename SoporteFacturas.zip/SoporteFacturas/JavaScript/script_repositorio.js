document.addEventListener('DOMContentLoaded', function () {
    const archivoInput = document.getElementById('archivo');
    const tamañoInput = document.getElementById('tamaño');
    const periodoInput = document.getElementById('periodo');
    const form = document.getElementById('formulario-carga');
    const progressBar = document.getElementById('progress-bar');
    const progressContainer = document.getElementById('progress-container');

    archivoInput.addEventListener('change', function () {
        let totalSize = 0;
        let isValid = true;
        let errorMessage = '';

        for (const file of archivoInput.files) {
            if (file.size > 1 * 1024 * 1024 * 1024) { // 1GB in bytes
                isValid = false;
                errorMessage += `El archivo ${file.name} excede el tamaño máximo de 1GB.<br>`;
            }

            if (file.type !== 'application/pdf') {
                isValid = false;
                errorMessage += `El archivo ${file.name} no es un archivo PDF.<br>`;
            }

            totalSize += file.size;
        }
        

        tamañoInput.value = (totalSize / 1024 / 1024).toFixed(2) + ' MB';

        if (!isValid) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                html: errorMessage,
            });
            archivoInput.value = ''; // Clear the input
        }
    });

    $(periodoInput).datepicker({
        format: "mm/yyyy",
        autoclose: true,
        startView: "months",
        minViewMode: "months"
    });

    form.addEventListener('submit', function (e) {
        e.preventDefault();

        if (form.checkValidity()) {
            const formData = new FormData(form);
            formData.append('accion', 'crearRepositorio');

            progressContainer.style.display = 'block';
            progressBar.style.width = '0%';
            progressBar.textContent = '0%';

            fetch('../Controller/repositorio_controller.php', {
                method: 'POST',
                body: formData,
            })
                .then(response => response.text()) // Primero obtener como texto
                .then(text => {
                    try {
                        return JSON.parse(text); // Intentar convertir a JSON
                    } catch (error) {
                        throw new Error('La respuesta no es un JSON válido: ' + text);
                    }
                })
                .then(response => {
                    if (response.error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            html: response.error,
                        }).then(() => {
                            location.reload(true);
                        });
                    } else {
                        progressBar.style.width = '100%';
                        progressBar.textContent = '100%';

                        Swal.fire({
                            icon: 'success',
                            title: 'Éxito',
                            text: 'Todos los archivos se han cargado correctamente.',
                        }).then(() => {
                            location.reload(true);
                        });
                    }
                })
                .catch(error => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error en la respuesta del servidor',
                        html: error.message,
                    });
                });
        } else {
            form.classList.add('was-validated');
        }
    });
});
