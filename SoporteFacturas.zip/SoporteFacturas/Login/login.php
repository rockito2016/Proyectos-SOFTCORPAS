<?php
session_start();

// Verificar si se ha enviado el formulario de inicio de sesión
if (isset($_POST['login'])) {
    // Obtener los datos del formulario
    $correo = $_POST['correo'];
    $tipoDocumento = $_POST['tipoDocumento'];

    // Realizar la consulta a la tabla "prestador"
    // Aquí debes ajustar la consulta según la estructura de tu tabla "prestador"
    $sql = "SELECT * FROM prestadores WHERE emailPrestador = :emailPrestador AND tipoDocumento = :tipoDocumento";

    // Realizar la conexión a la base de datos y preparar la consulta
    $dsn = 'mysql:host=localhost;dbname=soporte_facturas';
    $username = 'root';
    $password = '';
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    try {
        $pdo = new PDO($dsn, $username, $password, $options);
        $stmt = $pdo->prepare($sql);

        // Asignar los valores a los marcadores de posición en la consulta
        $stmt->bindParam(':emailPrestador', $correo);
        $stmt->bindParam(':tipoDocumento', $tipoDocumento);

        // Ejecutar la consulta
        $stmt->execute();

        // Verificar si se encontró un registro de prestador
        if ($stmt->rowCount() === 1) {
            // Iniciar sesión y redirigir a la vista principal
            $prestador = $stmt->fetch();
            $_SESSION['prestador'] = $prestador;
            header("Location: ../Views/vista_externo.php");
            exit();
        } else {
            // Mostrar alerta si no se encontró el prestador
            echo "<script>
                    alert('Credenciales inválidas. Por favor, verifica tus datos.');
                    window.location.href = '../Login/login.php'; 
                  </script>";
            exit();
        }
    } catch (PDOException $e) {
        // Manejo de errores en la conexión o consulta
        $error = "Error: " . $e->getMessage();
        echo "<script>
                alert('$error');
                window.location.href = '../Login/login.php'; 
              </script>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/5.4.0/collection/components.min.css">
    <style>
        .card {
            max-width: 400px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="card mt-5">
            <div class="card-body">
                <h2 class="text-center">
                    <i class="fas fa-sign-in-alt"></i> Iniciar Sesión
                </h2>
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="correo">
                            <i class="fas fa-envelope"></i> Correo:
                        </label>
                        <input type="email" id="correo" name="correo" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="tipoDocumento">
                            <i class="fas fa-id-card"></i> Tipo de Documento:
                        </label>
                        <input type="text" id="tipoDocumento" name="tipoDocumento" class="form-control" required>
                    </div>
                    <button type="submit" name="login" class="btn btn-primary btn-block">
                        <i class="fas fa-sign-in-alt"></i> Iniciar Sesión
                    </button>
                </form>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>