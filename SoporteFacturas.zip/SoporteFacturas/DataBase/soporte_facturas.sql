-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2024 at 06:25 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `soporte_facturas`
--

-- --------------------------------------------------------

--
-- Table structure for table `prestadores`
--

CREATE TABLE `prestadores` (
  `idPrestador` int(11) NOT NULL,
  `codPrestador` varchar(20) NOT NULL COMMENT 'llave primaria tabla prestadores',
  `prestador` varchar(100) NOT NULL COMMENT 'nombre prestador',
  `municipio` varchar(30) NOT NULL COMMENT 'municipio prestador',
  `nit` varchar(15) NOT NULL COMMENT 'nit prestador',
  `codMunicipio` varchar(5) DEFAULT NULL COMMENT 'codigo municipio',
  `codTarifaRetencion` smallint(6) NOT NULL DEFAULT 0 COMMENT 'CODIGO DE TARIFA DE RETENCIÓN SEGÚN TABLA FIN_PRESTADOR_TARIFA_RET',
  `porcentajeReteIca` float NOT NULL DEFAULT 0 COMMENT 'PORCENTAJE DE RETEICA. VALOR ENTRE 0 Y 100',
  `centroCosto` varchar(10) NOT NULL DEFAULT '0' COMMENT 'CENTRO DE COSTO(CONTRATO DE CONTABILIZACIÓN)',
  `periodoVencimiento` smallint(6) NOT NULL DEFAULT 0 COMMENT 'PERIODO EN MESES PARA VENCIMIENTO DE CUENTAS POR PAGAR',
  `auditor` int(11) DEFAULT NULL COMMENT 'auditor cuentas medicas asignado',
  `auxiliar` int(11) DEFAULT NULL COMMENT 'auxiliar cuentas medicas asignado',
  `telefonoPrestador` varchar(20) DEFAULT NULL COMMENT 'telefono prestador',
  `direccionPrestador` varchar(255) DEFAULT NULL COMMENT 'dirección prestador',
  `emailPrestador` varchar(255) DEFAULT NULL COMMENT 'email prestador',
  `tipoDocumento` char(3) NOT NULL COMMENT 'nit= NIT\r\nCC= Cédula ciudadanía CE= Cédula de extranjería CD= Carné diplomático PA= Pasaporte PE = Permiso Especial de Permanencia',
  `nivelPrestador` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci COMMENT='base de datos de la red de prestadores de servicios';

--
-- Dumping data for table `prestadores`
--

INSERT INTO `prestadores` (`idPrestador`, `codPrestador`, `prestador`, `municipio`, `nit`, `codMunicipio`, `codTarifaRetencion`, `porcentajeReteIca`, `centroCosto`, `periodoVencimiento`, `auditor`, `auxiliar`, `telefonoPrestador`, `direccionPrestador`, `emailPrestador`, `tipoDocumento`, `nivelPrestador`) VALUES
(2, '520190143401', 'ESE CENTRO DE SALUD SAN JOSE', 'ALBAN', '900131684', '52019', 100, 0, '89', 3, 4, 3, '3174307610', 'Centro', 'rouse.1912@hotmail.com', '454', NULL),
(3, '520220150601', 'E.S.E. CENTRO DE SALUD NUESTRA SEÑORA DEL PILAR', 'ALDANA', '900192678', '52022', 100, 0, '89', 3, 4, 2, '3122005339', 'CRA. 6 BARRIO EL PROGRESO', 'secregerenciaesealdana@gmail.com', '898', NULL),
(4, '520190129701', 'GLORIA ELIZABETH MORILLO ROSERO', 'ALBAN', '36752119', '52019', 100, 0, '89', 3, 4, 3, '3174307610', 'Centro', 'secretaria@esesanjosedealbannarino.gov.co', '170', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `radicacion`
--

CREATE TABLE `radicacion` (
  `idRadicacion` int(11) NOT NULL,
  `idPrestador` int(11) DEFAULT NULL,
  `idRepositorio` int(11) DEFAULT NULL,
  `idTipificacion` int(11) DEFAULT NULL,
  `fecha_ingreso` datetime DEFAULT NULL,
  `periodo` varchar(7) DEFAULT NULL,
  `archivo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `repositorio`
--

CREATE TABLE `repositorio` (
  `idRepositorio` int(11) NOT NULL,
  `fecha_ingreso` datetime NOT NULL DEFAULT current_timestamp(),
  `estado` varchar(1) NOT NULL DEFAULT 'A',
  `archivo` varchar(255) NOT NULL,
  `periodo` varchar(7) NOT NULL,
  `tamaño` blob DEFAULT NULL,
  `idPrestador` int(11) DEFAULT NULL,
  `idTipificacion` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `repositorio`
--

INSERT INTO `repositorio` (`idRepositorio`, `fecha_ingreso`, `estado`, `archivo`, `periodo`, `tamaño`, `idPrestador`, `idTipificacion`) VALUES
(478, '2024-05-22 00:19:23', 'a', '../../Prestador/4/01/2024/Curso_de_HTML.pdf', '01/2024', 0x323530, 4, 17),
(479, '2024-05-22 00:19:23', 'a', '../../Prestador/4/01/2024/Kali_Linux_v2_ReYDeS.pdf', '01/2024', 0x3230373633, 4, 17),
(480, '2024-05-22 00:19:23', 'a', '../../Prestador/4/01/2024/pdf-poo-y-mvc-en-php_compress.pdf', '01/2024', 0x31353731, 4, 17),
(481, '2024-05-22 00:19:23', 'a', '../../Prestador/4/01/2024/Tutorial_Kotlin_Ya.pdf', '01/2024', 0x3131313232, 4, 17),
(482, '2024-05-22 00:19:23', 'a', '../../Prestador/4/01/2024/00168_Dominar_la_administracion_del_sistema_Linux.pdf', '01/2024', 0x3231323536, 4, 17),
(483, '2024-05-22 00:19:23', 'a', '../../Prestador/4/01/2024/Programador-PHP.pdf', '01/2024', 0x31323435, 4, 17),
(484, '2024-05-22 00:19:23', 'a', '../../Prestador/4/01/2024/Introduccion_a_las_Estructuras_de_Datos.pdf', '01/2024', 0x3132393831, 4, 17),
(485, '2024-05-22 00:19:23', 'a', '../../Prestador/4/01/2024/Fundamentos_de_programcion_en_Java.pdf', '01/2024', 0x373838, 4, 17),
(486, '2024-05-22 00:19:23', 'a', '../../Prestador/4/01/2024/Definicion-de-situaciones-y-manejo-de-casos.pdf', '01/2024', 0x35343236, 4, 17),
(487, '2024-05-22 00:20:54', 'a', '../../Prestador/4/02/2024/Trabajo_final.pdf', '02/2024', 0x32313231, 4, 19),
(488, '2024-05-22 00:20:54', 'a', '../../Prestador/4/02/2024/diplomado.pdf', '02/2024', 0x313536, 4, 19),
(489, '2024-05-22 00:20:54', 'a', '../../Prestador/4/02/2024/Avance_de_práctica.pdf', '02/2024', 0x3633, 4, 19),
(491, '2024-05-22 00:28:39', 'a', '../../Prestador/4/03/2024/angular-cheat-sheet.pdf', '03/2024', 0x343237, 4, 16);

-- --------------------------------------------------------

--
-- Table structure for table `tipificacion`
--

CREATE TABLE `tipificacion` (
  `idTipificacion` int(3) NOT NULL,
  `idPrestador` int(11) DEFAULT NULL,
  `tipificacion` varchar(3) DEFAULT NULL,
  `descripcion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tipificacion`
--

INSERT INTO `tipificacion` (`idTipificacion`, `idPrestador`, `tipificacion`, `descripcion`) VALUES
(5, 2, 'HEV', 'prueba'),
(6, 2, 'FMO', 'prueba2'),
(7, 3, 'HEV', 'prueba3'),
(8, 3, 'HAM', 'prueba4'),
(9, 3, 'FAT', 'prueba5'),
(10, 3, 'CRC', 'prueba6'),
(11, 2, 'TNA', 'prueba7'),
(12, 2, 'RAN', 'prueba8'),
(13, 4, 'FAT', 'prueba9'),
(14, 3, 'HAU', 'prueba10'),
(15, 2, 'EPI', 'prueba'),
(16, 4, 'HEV', 'prueba55'),
(17, 4, 'TNA', 'prueba'),
(18, 4, 'DQX', 'prueba556'),
(19, 4, 'FMO', 'prueba'),
(20, 2, 'DQX', 'pruebaaa'),
(21, 2, 'PDE', 'prueba'),
(22, 3, 'EPI', 'prueba');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `prestadores`
--
ALTER TABLE `prestadores`
  ADD PRIMARY KEY (`idPrestador`);

--
-- Indexes for table `radicacion`
--
ALTER TABLE `radicacion`
  ADD PRIMARY KEY (`idRadicacion`),
  ADD KEY `idPrestador` (`idPrestador`),
  ADD KEY `idRepositorio` (`idRepositorio`),
  ADD KEY `idTipificacion` (`idTipificacion`);

--
-- Indexes for table `repositorio`
--
ALTER TABLE `repositorio`
  ADD PRIMARY KEY (`idRepositorio`),
  ADD KEY `idPrestador` (`idPrestador`,`idTipificacion`);

--
-- Indexes for table `tipificacion`
--
ALTER TABLE `tipificacion`
  ADD PRIMARY KEY (`idTipificacion`),
  ADD KEY `idPrestador` (`idPrestador`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `prestadores`
--
ALTER TABLE `prestadores`
  MODIFY `idPrestador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=540;

--
-- AUTO_INCREMENT for table `repositorio`
--
ALTER TABLE `repositorio`
  MODIFY `idRepositorio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=492;

--
-- AUTO_INCREMENT for table `tipificacion`
--
ALTER TABLE `tipificacion`
  MODIFY `idTipificacion` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `radicacion`
--
ALTER TABLE `radicacion`
  ADD CONSTRAINT `radicacion_ibfk_1` FOREIGN KEY (`idPrestador`) REFERENCES `prestadores` (`idPrestador`),
  ADD CONSTRAINT `radicacion_ibfk_2` FOREIGN KEY (`idRepositorio`) REFERENCES `repositorio` (`idRepositorio`),
  ADD CONSTRAINT `radicacion_ibfk_3` FOREIGN KEY (`idTipificacion`) REFERENCES `tipificacion` (`idTipificacion`);

--
-- Constraints for table `repositorio`
--
ALTER TABLE `repositorio`
  ADD CONSTRAINT `repositorio_ibfk_1` FOREIGN KEY (`idPrestador`) REFERENCES `prestadores` (`idPrestador`),
  ADD CONSTRAINT `repositorio_ibfk_2` FOREIGN KEY (`idPrestador`,`idTipificacion`) REFERENCES `tipificacion` (`idPrestador`, `idTipificacion`);

--
-- Constraints for table `tipificacion`
--
ALTER TABLE `tipificacion`
  ADD CONSTRAINT `tipificacion_ibfk_1` FOREIGN KEY (`idPrestador`) REFERENCES `prestadores` (`idPrestador`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
