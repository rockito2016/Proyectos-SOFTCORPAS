<?php
session_start();
include ('../conexion.php');

// Obtener los valores de los parámetros GET
$tipificacion = isset($_GET['tipificacion']) ? $_GET['tipificacion'] : '';
$idPrestador = $_GET['idPrestador'];

// Construir la consulta SQL
$query = "SELECT r.fecha_ingreso, r.estado, r.archivo, r.periodo
          FROM repositorio r
          INNER JOIN tipificacion t ON r.idTipificacion = t.idTipificacion
          WHERE r.idPrestador = :idPrestador";

// Añadir el filtro de tipificación si se proporciona
if ($tipificacion) {
    $query .= " AND t.tipificacion = :tipificacion";
}

$stmt = $miconexion->prepare($query);
$stmt->bindParam(':idPrestador', $idPrestador, PDO::PARAM_INT);

if ($tipificacion) {
    $stmt->bindParam(':tipificacion', $tipificacion, PDO::PARAM_STR);
}

$stmt->execute();

// Obtener los resultados de la consulta
$resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Devolver los resultados en formato JSON
echo json_encode($resultados);