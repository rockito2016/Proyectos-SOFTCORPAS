<?php

include('../conexion.php');
class Object_tipificacion
{
	private $tipificacion;
	private $descripcion;
	private $idPrestador;

	public function setTipificacion($tipificacion)
	{
		$this->tipificacion = $tipificacion;
	}
	public function getTipificacion()
	{
		return $this->tipificacion;
	}
	public function setDescripcion($descripcion)
	{
		$this->descripcion = $descripcion;
	}
	public function getDescripcion()
	{
		return $this->descripcion;
	}

	public function setidPrestador($idPrestador){
		$this->idPrestador = $idPrestador;
	}
	public function getidPrestador(){
		return $this->idPrestador;
	}
}
