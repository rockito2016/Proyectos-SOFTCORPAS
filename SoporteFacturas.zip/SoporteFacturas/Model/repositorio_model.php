<?php
class Repositorio_model
{
    private $conexion;
    private $carpeta_ruta;

    public function __construct(PDO $conexion, $ruta_archivos)
    {
        $this->conexion = $conexion;
        $this->carpeta_ruta = $ruta_archivos;
    }

    public function existe_Archivo($archivo_nombre, $idPrestador)
    {
        $stmt = $this->conexion->prepare("SELECT COUNT(*) AS count FROM repositorio WHERE archivo = ? AND idPrestador = ?");
        $stmt->execute([$archivo_nombre, $idPrestador]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result['count'] > 0;
    }

    public function periodoExiste($periodo, $idPrestador)
    {
        $stmt = $this->conexion->prepare("SELECT COUNT(*) AS count FROM repositorio WHERE periodo = ? AND idPrestador = ?");
        $stmt->execute([$periodo, $idPrestador]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result['count'] > 0;
    }

    public function Existe_tipificacion($tipificacion, $idPrestador)
    {
        $stmt = $this->conexion->prepare("SELECT COUNT(*) AS count FROM tipificacion WHERE tipificacion = ? AND idPrestador = ?");
        $stmt->execute([$tipificacion, $idPrestador]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result['count'] > 0;
    }

    public function insertar_Tipificacion($idPrestador, $tipificacion, $descripcion)
    {
        $stmt = $this->conexion->prepare("INSERT INTO tipificacion (idPrestador, tipificacion, descripcion) VALUES (?, ?, ?)");
        $stmt->execute([$idPrestador, $tipificacion, $descripcion]);
        return $this->conexion->lastInsertId();
    }

    public function obtener_Id_Tipificado($tipificacion, $idPrestador)
    {
        $stmt = $this->conexion->prepare("SELECT idTipificacion FROM tipificacion WHERE tipificacion = ? AND idPrestador = ?");
        $stmt->execute([$tipificacion, $idPrestador]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['idTipificacion'];
    }

    public function crear_Carpeta($ruta)
    {
        if (!file_exists($ruta)) {
            mkdir($ruta, 0777, true);
        }
    }

    public function insertar_Archivo($ruta_completa, $periodo, $tamaño, $idPrestador, $archivo_temporal, $idTipificacion)
    {
        $estado = 'activo';

        if (!move_uploaded_file($archivo_temporal, $ruta_completa)) {
            return ["error" => "Error al mover el archivo {$ruta_completa}."];
        }

        $stmt = $this->conexion->prepare("INSERT INTO repositorio (archivo, periodo, tamaño, idPrestador, estado, idTipificacion) VALUES (?, ?, ?, ?, ?, ?)");
        if ($stmt->execute([$ruta_completa, $periodo, $tamaño, $idPrestador, $estado, $idTipificacion])) {
            return ["mensaje" => "El archivo {$ruta_completa} se ha subido exitosamente."];
        } else {
            return ["error" => "Error al insertar el archivo {$ruta_completa} en la base de datos."];
        }
    }

    public function validar_Archivo($archivo_nombre, $archivo_temporal)
    {
        $fileSize = filesize($archivo_temporal) / (1024 * 1024); // Tamaño en megabytes
        $fileType = strtolower(pathinfo($archivo_nombre, PATHINFO_EXTENSION));

        // Validar que el archivo sea un PDF y que su tamaño no exceda 1GB
        if ($fileSize > 1000 || $fileType !== 'pdf') {
            return false;
        }

        return true;
    }
}