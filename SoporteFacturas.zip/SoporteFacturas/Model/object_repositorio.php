<?php

include('../conexion.php');

class Object_repositorio
{
	private $periodo;
	private $archivo;
	private $estado;
	private $tamaño;
	private $idPrestador;
	private $fecha_ingreso;

	public function setPeriodo()
	{
		return $this->periodo;
	}
	public function getPeriodo($periodo)
	{
		$this->periodo = $periodo;
	}
	public function setEstado()
	{
		return $this->estado;
	}
	public function getEstado($estado)
	{
		$this->estado = $estado;
	}
	public function setTamaño()
	{
		return $this->tamaño;
	}
	public function getTamaño($tamaño)
	{
		$this->tamaño = $tamaño;
	}
	public function setFecha_ingreso()
	{
		return $this->fecha_ingreso;
	}
	public function getFecha_ingreso($fecha_ingreso)
	{
		$this->fecha_ingreso = $fecha_ingreso;
	}
	public function setArchivo() {
		return $this->archivo;
	}
	public function getArchivo($archivo) {
        $this->archivo = $archivo;
    }

	public function setidPrestador(){
		return $this->idPrestador;
	}
	public function getidPrestador($idPrestador){
		$this->idPrestador = $idPrestador;
	}
}
